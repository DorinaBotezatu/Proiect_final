
"""
    Avem aplicatia care tine stocul unui depozit (Vezi Cap 5-6). Efectuati urmatoarele imbunatatiri:
	

1. Adaugati o metoda in clasa Stoc care sa ofere o proiectie grafica a intrarilor si iesirilor intr-o
anumita perioada, pentru un anumit produs;	--pygal--

2. Adaugati o solutie in clasa Stoc care sa va avertizeze automat cand stocul unui produs este mai mic decat o 
limita minima, predefinita per produs. Limita sa poata fi variabila (per produs). Preferabil sa 
transmita automat un email de avertizare;

3. Adaugati o metoda in clasa Stoc care sa transmita prin email diferite informatii(
de exemplu fisa produsului) ; 	--SMTP--

4. Adaugati o metoda in clasa Stoc care sa utilizeze Regex pentru a cauta :
    - un produs introdus de utilizator;
    - o tranzactie cu o anumita valoare introdusa de utilizator;	--re--

5. Completati aplicatia astfel incat sa permita introducerea pretului la fiecare intrare si iesire.
Pretul de iesire va fi pretul mediu ponderat (la fiecare tranzactie de intrare se va face o medie intre
pretul produselor din stoc si al celor intrate ceea ce va deveni noul pret al produselor stocate).
Pretul de iesire va fi pretul din acel moment;  

6. Creati trei metode noi, diferite de cele facute la clasa, testati-le si asigurati-va ca functioneaza cu succes;


""" #
